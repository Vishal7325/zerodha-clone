// Simple frontend logic using localStorage to persist demo balances & history

// Utilities
const $ = id => document.getElementById(id);
const qs = sel => document.querySelector(sel);
const qsa = sel => document.querySelectorAll(sel);

function formatINR(x) {
  return '₹' + Number(x).toFixed(2);
}

// localStorage keys
const BAL_KEY = 'fastag_balances';
const HIST_KEY = 'fastag_history';

// load data
function loadBalances() {
  return JSON.parse(localStorage.getItem(BAL_KEY) || '{}');
}
function saveBalances(bal) {
  localStorage.setItem(BAL_KEY, JSON.stringify(bal));
}
function loadHistory() {
  return JSON.parse(localStorage.getItem(HIST_KEY) || '[]');
}
function saveHistory(h) {
  localStorage.setItem(HIST_KEY, JSON.stringify(h));
}

// Demo: initialize with a sample vehicle if empty
(function initDemo() {
  const b = loadBalances();
  if (!b['MH12AB1234']) {
    b['MH12AB1234'] = 250.00;
    saveBalances(b);
  }
  renderHistory();
})();

// Quick balance check
document.getElementById('checkBtn').addEventListener('click', () => {
  const v = document.getElementById('vehicleInput').value.trim().toUpperCase();
  const out = document.getElementById('balanceResult');
  if (!v) { out.innerHTML = '<div class="text-danger">Enter vehicle number.</div>'; return; }
  const balances = loadBalances();
  if (balances[v] !== undefined) {
    out.innerHTML = `<div class="alert alert-success mb-0">Balance for <strong>${v}</strong>: ${formatINR(balances[v])}</div>`;
  } else {
    out.innerHTML = `<div class="alert alert-warning mb-0">No FASTag found for <strong>${v}</strong>. You can <a href="#buy">buy a FASTag</a> or <a href="#recharge">recharge</a>.</div>`;
  }
});

// Buy FASTag (simulate order)
document.getElementById('buyForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const name = document.getElementById('buyerName').value.trim();
  const mobile = document.getElementById('buyerMobile').value.trim();
  const vehicle = document.getElementById('vehicleNo').value.trim().toUpperCase();
  const vtype = document.getElementById('vehicleType').value;

  if (!name || !mobile || !vehicle) {
    document.getElementById('buyResult').innerHTML = '<div class="text-danger">Please fill all fields.</div>';
    return;
  }

  // simulate creating FASTag with zero balance
  const balances = loadBalances();
  balances[vehicle] = balances[vehicle] || 0;
  saveBalances(balances);

  const orderId = 'FT' + Date.now().toString().slice(-8);
  const msg = `<div class="alert alert-success">Order placed! <strong>Order ID:</strong> ${orderId}. FASTag assigned to <strong>${vehicle}</strong>. You can now recharge it.</div>`;
  document.getElementById('buyResult').innerHTML = msg;
  document.getElementById('buyForm').reset();
  renderHistory();
});

// Recharge FASTag
document.getElementById('rechargeForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const vehicle = document.getElementById('reVehicle').value.trim().toUpperCase();
  const amount = Number(document.getElementById('reAmount').value);

  if (!vehicle || !amount || amount <= 0) {
    document.getElementById('rechargeMsg').innerHTML = '<div class="text-danger">Enter valid vehicle number and amount.</div>';
    return;
  }

  // update balance
  const balances = loadBalances();
  balances[vehicle] = (balances[vehicle] || 0) + amount;
  saveBalances(balances);

  // save history
  const history = loadHistory();
  history.unshift({ vehicle, amount, time: new Date().toISOString() });
  saveHistory(history);

  document.getElementById('rechargeMsg').innerHTML = `<div class="alert alert-success mb-0">Recharged ${formatINR(amount)} for ${vehicle}. New balance: ${formatINR(balances[vehicle])}</div>`;
  document.getElementById('rechargeForm').reset();
  renderHistory();
});

// render history
function renderHistory() {
  const history = loadHistory();
  const el = document.getElementById('historyList');
  if (!history.length) {
    el.innerHTML = '<div class="text-muted">No transactions yet.</div>';
    return;
  }
  const rows = history.map(h => {
    const t = new Date(h.time);
    return `<div class="history-row">
      <div>
        <div><strong>${h.vehicle}</strong> <small class="text-muted">(${t.toLocaleString()})</small></div>
        <div class="text-muted small">Recharged ${formatINR(h.amount)}</div>
      </div>
      <div class="text-end">
        <div class="small text-muted">${formatINR(h.amount)}</div>
      </div>
    </div>`;
  }).join('');
  el.innerHTML = rows;
}

// bottom-nav click behavior (scroll to section)
document.querySelectorAll('.bottom-nav .nav-item').forEach(item => {
  item.addEventListener('click', () => {
    document.querySelectorAll('.bottom-nav .nav-item').forEach(i => i.classList.remove('active'));
    item.classList.add('active');
    const target = item.getAttribute('data-target');
    if (target) {
      document.querySelector(target).scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});

// demo button: fill demo values
document.getElementById('demoBtn').addEventListener('click', () => {
  document.getElementById('vehicleInput').value = 'MH12AB1234';
  document.getElementById('reVehicle').value = 'MH12AB1234';
  document.getElementById('reAmount').value = 500;
  document.getElementById('buyResult').innerHTML = '';
  const balances = loadBalances();
  document.getElementById('balanceResult').innerHTML = `<div class="alert alert-info mb-0">Demo balance for MH12AB1234: ${formatINR(balances['MH12AB1234'] || 0)}</div>`;
});
