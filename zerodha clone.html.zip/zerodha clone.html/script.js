// Example: Navbar scroll effect
window.addEventListener('scroll', function() {
  const nav = document.querySelector('.navbar');
  if (window.scrollY > 50) {
    nav.classList.add('shadow');
  } else {
    nav.classList.remove('shadow');
  }
});
// Highlight active nav icon
const navItems = document.querySelectorAll('.bottom-nav .nav-item');
navItems.forEach(item => {
  item.addEventListener('click', () => {
    navItems.forEach(i => i.classList.remove('active'));
    item.classList.add('active');
  });
});
// Simulate live price change
function randomPriceChange() {
  document.querySelectorAll('.list-group-item').forEach(item => {
    const priceElem = item.querySelector('.fw-bold');
    const changeElem = item.querySelector('small.text-success, small.text-danger');

    if (!priceElem || !changeElem) return;

    let price = parseFloat(priceElem.textContent.replace(/[₹,]/g, ''));
    let change = (Math.random() * 2 - 1).toFixed(2); // random -1% to +1%

    price = (price + (price * change / 100)).toFixed(2);

    priceElem.textContent = `₹${price}`;
    if (change >= 0) {
      changeElem.textContent = `+${change}%`;
      changeElem.classList.add('text-success');
      changeElem.classList.remove('text-danger');
    } else {
      changeElem.textContent = `${change}%`;
      changeElem.classList.add('text-danger');
      changeElem.classList.remove('text-success');
    }
  });
}

// Update every 5 seconds
setInterval(randomPriceChange, 5000);

